__title__='paquete'
__version__='0.0.1'
__author__='Raul Villano'
__email__='raulengineer@gmail.com'
__description__='Este es un modulo de prueba para ejecutar ucprotect'
__url__="https://github.com/raulengineer/tutorial.git"